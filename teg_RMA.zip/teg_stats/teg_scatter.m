function teg_scatter(varargin)

% function teg_scatter(x, y[, linear])
%
% If linear = 0, a logit link function is used, but y must be in (0, 1].

x = varargin{1};
y = varargin{2};
if length(varargin) > 2,
    lin0 = varargin{3};
else,
    lin0 = 1;
end;

x = x(:);
y = y(:);

s0 = scatter(x, y);
set(s0, 'CData', [0, 0, 0]);
set(c(2), 'MarkerFaceColor', 'flat');

hold on;

if lin0 == 1,
    [b, F, df1, df2, p, R2, pred, se_b, t_b, p_b, R2_adj, change_R2_adj] = teg_regression(x, y, []);
else,
    [x, si] = sort(x);
    yn = y(si);
    yn0 = 0;
    ynmax = 1;
    if min(yn) <= 0 || max(y) > 1,
        yn0 = min(yn);
        yn = yn - yn0;
        yn = yn + min(1e-3, max(yn) / 1e3); % Remove hard zero
        ynmax = max(yn);
        yn = yn ./ ynmax;
    end;
    glm = fitglm(x, yn, 'linear', 'Link', 'logit');
    pred = glm.predict;
    pred = pred * ynmax;
    pred = pred + yn0;
end;
plot(x, pred, 'k-')

minx = min(x);
maxx = max(x);
bufx = (maxx - minx) * 0.05;
xlim([minx - bufx, maxx + bufx]);

miny = min([y; pred]);
maxy = max([y; pred]);
bufy = (maxy - miny) * 0.05;
ylim([miny - bufy, maxy + bufy]);

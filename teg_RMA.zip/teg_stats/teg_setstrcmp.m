function O = teg_setstrcmp()


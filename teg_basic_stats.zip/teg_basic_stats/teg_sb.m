function sb = teg_sb(varargin)

% function sb = teg_sb(r)
% function sb = teg_sb(r, n)

r = varargin{1};
n = 2;
if length(varargin) == 2
    n = varargin{2};
    if length(n) > 1
        error('This function now does not accept vectors to do the correlation');
    end
end
sb = sign(r) * n * abs(r) / (1 + (n - 1) * abs(r));
if r < 0
    sb = -sb;
end

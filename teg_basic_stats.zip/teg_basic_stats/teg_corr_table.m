function all_p = teg_corr_table(varargin)

% function all_p = teg_corr_table(M[, varnames, toShow{1, 2}, verbose0, crit3star])

all_p = [];

% corrtypestr = 'Pearson';
corrtypestr = 'Spearman';

M = varargin{1};

if length(varargin) > 1,
    varnames = varargin{2};
else,
    varnames = {};
    for iv = 1:size(M, 2),
        varnames{iv} = ['V' num2str(iv)];
    end;
end;

if length(varargin) > 2,
    cols_to_show = varargin{3};
else,
    cols_to_show{1} = 1:size(M, 2);
    cols_to_show{2} = 1:size(M, 2);
end;
if isempty(cols_to_show),
    cols_to_show{1} = 1:size(M, 2);
    cols_to_show{2} = 1:size(M, 2);
end;

if length(varargin) > 3,
    verbose0 = varargin{4};
else,
    verbose0 = [];
end;
if isempty(verbose0),
    verbose0 = 1;
end;

vc = 1:length(varnames);
nV = length(vc);
nTests = (nV * nV - nV) / 2;

if length(varargin) > 4,
    critp3 = varargin{5};
else,
    critp3 = [];
end;
if isempty(critp3),
    critp3 = 0.05 / nTests;
end;


corrstr = {};
for iv1 = 1:length(vc),
    for iv2 = 1:length(vc),
        M2 = M(:, [iv1 iv2]);
        f = find(isnan(mean(M2')'));
        M2(f, :) = [];
        try,
            [C, P] = corr(M2, 'type', corrtypestr);
        catch,
            C = NaN * ones(2, 2);
            P = 1 * ones(2, 2);
        end;
        if verbose0 > 0,
            if P(1, 2) < critp3,
                siglab = ' **';
            elseif P(1, 2) < 0.05,
                siglab = ' *';
            else,
                siglab = '';
            end;
            siglab = [' ' num2str(P(1, 2)) siglab];
            str0 = [num2str(C(1, 2), 2) siglab];
            corrstr{iv1, iv2} = str0;
        end;
        if iv1 < iv2,
            if teg_in(iv1, cols_to_show{1}) > 0 && teg_in(iv2, cols_to_show{2}) > 0,
                all_p = [all_p; P(1, 2)];
            end;
        end;
    end;
end;

if verbose0 == 0,
    return;
end;

maxlen = 1;
for iv = 1:length(vc),
    l0 = length(varnames{vc(iv)});
    if l0 > maxlen,
        maxlen = l0;
    end;
end;
for iv1 = 1:length(vc),
    for iv2 = 1:length(vc),
        l0 = length(corrstr{iv1, iv2});
        if l0 > maxlen,
            maxlen = l0;
        end;
    end;
end;

eqlenlabs = {};
for iv = 1:length(vc),
    thisvn = varnames{vc(iv)};
    eqlenlabs{iv} = thisvn;
    filler0 = ' ';
    for il = 1:(maxlen - length(thisvn)),
        eqlenlabs{iv} = [eqlenlabs{iv} filler0];
    end;
end;
for iv1 = 1:length(vc),
    for iv2 = 1:length(vc),
        thiscs = corrstr{iv1, iv2};
        if mod(iv1, 2) == 0,
            filler0 = ' ';
        else,
            filler0 = ' ';
        end;
        for il = 1:(maxlen - length(thiscs)),
            corrstr{iv1, iv2} = [corrstr{iv1, iv2} filler0];
        end;
    end;
end;

for il = 1:maxlen,
    fprintf([' ']);
end;
fprintf(['\t']);
for iv1 = 1:length(vc),
    fprintf([eqlenlabs{iv1} '\t']);
end;
fprintf('\n');

for iv1 = 1:length(vc),
    for iv2 = 1:length(vc),
        if iv2 == 1,
            fprintf([num2str(iv1) '. ' eqlenlabs{iv1} '\t']);
        end;
        str0 = corrstr{iv1, iv2};
        fprintf([str0 '\t']);
    end;
    fprintf('\n');
end;

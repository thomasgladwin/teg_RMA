function [fOut, abnv] = teg_outliers_corr(v1, v2)

crit0 = 5;

z1 = zscore(v1);
z2 = zscore(v2);
abnv = [];
for n = 1:length(v1),
    tmp1 = z1;
    tmp2 = z2;
    tmp1(n) = [];
    tmp2(n) = [];
    [b, F, df1, df2, p, R2, pred, se_b, t_b, p_b, R2_adj, change_R2_adj] = teg_regression(tmp1, tmp2, [], 0);
    pred_n = b(end) + b(1) * z1(n);
    abn0 = abs(z2(n) - pred_n);
    abnv = [abnv; abn0];
end;
fOut = find(abnv > crit0);

function a = teg_cronbach(M)

% function teg_cronbach(M)
%
% Rows are observations, columns are testlets
C = cov(M);

T = triu(C, 1);
[nR, nC] = size(C);
NT = ((nR * nC) - nC) / 2;
mean_cov = sum(T(:)) / NT;

variances0 = diag(C);
mean_v = mean(variances0(:));

K = nC;

a = (K * mean_cov) / (mean_v + (K - 1) * mean_cov);

function P = teg_triu_NaNs(P, k)

% function P = teg_triu_NaNs(P, k)

for n = 1:size(P, 1),
    for m = 1:(n + k - 1)
        P(n, m) = NaN;
    end
end

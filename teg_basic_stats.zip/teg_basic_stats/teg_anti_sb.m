function r = teg_anti_sb(sb)

% function r = teg_anti_sb(sb)

r = 1 / (2 / sb - 1);


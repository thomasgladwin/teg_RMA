function pcrit = teg_perm_test(M1, M1labels, M2, M2labels, nIts)

% function [pcrit] = teg_perm_test(M1, M1labels, M2, M2labels, nIts)

report = 1;
cortype = 'Spearman';
nompcrit = 0.05;

minpv = NaN * zeros(nIts, 1);
nnomsigv = NaN * zeros(nIts, 1);
for iIt = 1:nIts
    this_p_set = [];
    for iM1 = 1:size(M1, 2)
        v1 = M1(:, iM1);
        v1 = v1(randperm(length(v1)));
        f = find(~isnan(mean([v1 M2], 2)));
        if isempty(f)
            continue;
        end
        [C, P] = corr([v1(f, :), M2(f, :)], 'type', cortype);
        P = P(1, :);
        this_p_set = [this_p_set P];
    end;
    minp = min(P(:));
    minpv(iIt) = minp;
    nnomsigv(iIt) = length(find(P < nompcrit));
end

minpvs = sort(minpv, 'ascend');
ind5 = ceil(0.05 * length(minpvs));
pcrit_base = minpvs(ind5);
u = unique(minpv);
f = find(u == pcrit_base);
if f > 1
    pcrit = u(f - 1);
else
    pcrit = 0;
end

if report == 1
    fprintf(['True p-crit = ' num2str(pcrit) '\n'])
end

n_obs_nomsig = 0;
n_tests = 0;
for iM1 = 1:size(M1, 2)
    v1 = M1(:, iM1);
    f = find(~isnan(mean([v1 M2], 2)));
    if isempty(f)
        continue;
    end
    [C, P] = corr([v1(f, :), M2(f, :)], 'type', cortype);
    for iiM2 = 2:size(P, 2)
        iM2 = iiM2 - 1;
        if P(1, iiM2) < pcrit
            fprintf([M1labels{iM1} ' x ' M2labels{iM2} ': r = ' num2str(C(1, iiM2)) ', p = ' num2str(P(1, iiM2)) ' ***\n'])
        elseif P(1, iiM2) < nompcrit
            fprintf([M1labels{iM1} ' x ' M2labels{iM2} ': r = ' num2str(C(1, iiM2)) ', p = ' num2str(P(1, iiM2)) ' *\n'])
        else
            fprintf([M1labels{iM1} ' x ' M2labels{iM2} ': r = ' num2str(C(1, iiM2)) ', p = ' num2str(P(1, iiM2)) '\n'])
        end
        if P(1, iiM2) < nompcrit
            n_obs_nomsig = n_obs_nomsig + 1;
        end
        n_tests = n_tests + 1;
    end;
end;

f = find(nnomsigv >= n_obs_nomsig);
pnnom = length(f) / length(nnomsigv);
fprintf(['Significance of number of nomsigs: n = ' num2str(n_obs_nomsig) ', prop = ' num2str(n_obs_nomsig / n_tests) ', p = ' num2str(pnnom) '\n']);

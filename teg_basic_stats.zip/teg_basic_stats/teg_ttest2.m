function [pv, tv, dfv, effs] = teg_ttest2(varargin)

% function [pv, tv, dfv, effs] = teg_ttest2(v1, v2[, report0])
%
% Diff = 1 minus 2

v1 = varargin{1};
v2 = varargin{2};
[H,P,CI,STATS] = ttest2(v1, v2);
dm = mean(v1) - mean(v2);
effs = dm / STATS.sd;
tv = STATS.tstat;
pv = P;
dfv = STATS.df;
if length(varargin) > 2
    if varargin{3} == 1
        fprintf(['t(' num2str(STATS.df) ') = ' num2str(STATS.tstat, 3) ', p = ' num2str(P, 3) ', d = ' num2str(effs) '\n']);
    end
end

